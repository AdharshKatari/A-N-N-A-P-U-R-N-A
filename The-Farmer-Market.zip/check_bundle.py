import requests
import re

r = requests.get('http://localhost:8082/node_modules/expo/AppEntry.bundle?platform=web&dev=true&hot=false&lazy=true&transform.engine=hermes&transform.routerRoot=app&unstable_transformProfile=hermes-stable')

matches = re.findall(r'localhost:\d{4}', r.text[:50000])
print('Found ports:', set(matches))

matches = re.findall(r'API_BASE_URL.*?[\'"]([^\'"]+)', r.text[:50000])
print('API_BASE_URL:', matches[:5])