import requests
import re

r = requests.get('http://localhost:8082/node_modules/expo/AppEntry.bundle?platform=web&dev=true&hot=false&lazy=true&transform.engine=hermes&transform.routerRoot=app&unstable_transformProfile=hermes-stable')

# Search for the API URL pattern
if '8001' in r.text:
    print('Found 8001 in bundle')
    idx = r.text.index('8001')
    print(r.text[max(0,idx-50):idx+50])
else:
    print('8001 NOT found in bundle')

if '8000' in r.text:
    print('Found 8000 in bundle')
    idx = r.text.index('8000')
    print(r.text[max(0,idx-50):idx+50])
else:
    print('8000 NOT found in bundle')

if 'API_BASE_URL' in r.text:
    print('Found API_BASE_URL in bundle')
    idx = r.text.index('API_BASE_URL')
    print(r.text[max(0,idx-50):idx+100])
else:
    print('API_BASE_URL NOT found in bundle')

# Search for http://localhost
matches = re.findall(r'http://localhost:\d{4}', r.text)
print('Full URLs found:', set(matches))