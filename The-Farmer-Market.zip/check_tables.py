import psycopg2
conn = psycopg2.connect('postgres://avnadmin:AVNS_33570aoBUOJbC4VEPk9@pg-2bd28f24-shahidkhan07191-2f4c.k.aivencloud.com:28479/defaultdb?sslmode=require')
cur = conn.cursor()
cur.execute("SELECT table_name FROM information_schema.tables WHERE table_schema = 'public'")
tables = cur.fetchall()
for t in tables:
    print(t[0])