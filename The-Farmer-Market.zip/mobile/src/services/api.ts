/**
 * Annapurna API Service Layer
 * Connects to the FastAPI backend at /api/v5/*
 * Includes: timeout, retry, offline queue, auth refresh, error normalization
 */

import AsyncStorage from '@react-native-async-storage/async-storage';
import { API_BASE_URL, DEFAULT_HEADERS, REQUEST_TIMEOUT_MS } from '../constants/api';
import { enqueueTransaction, isOnline } from '../utils/offlineQueue';

export { isOnline };

const BASE_URL = API_BASE_URL;

export interface ApiError extends Error {
  status?: number;
  code?: string;
  apiStatus?: string;
  isOffline?: boolean;
  isRetryable?: boolean;
}

export interface ApiResponse<T> {
  data: T | null;
  error: ApiError | null;
  fromCache: boolean;
}

async function getAuthToken(): Promise<string | null> {
  try {
    return await AsyncStorage.getItem('auth_token');
  } catch {
    return null;
  }
}

async function refreshAuthToken(): Promise<string | null> {
  try {
    const refreshToken = await AsyncStorage.getItem('refresh_token');
    if (!refreshToken) return null;

    const response = await fetch(`${BASE_URL}/api/v5/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refresh_token: refreshToken }),
    });

    if (response.ok) {
      const data = await response.json();
      await AsyncStorage.setItem('auth_token', data.access_token);
      if (data.refresh_token) {
        await AsyncStorage.setItem('refresh_token', data.refresh_token);
      }
      return data.access_token;
    }
  } catch (err) {
    console.error('Token refresh failed:', err);
  }
  return null;
}

function createApiError(message: string, options: {
  status?: number;
  code?: string;
  apiStatus?: string;
  isOffline?: boolean;
  isRetryable?: boolean;
} = {}): ApiError {
  const err = new Error(message) as ApiError;
  err.status = options.status;
  err.code = options.code;
  err.apiStatus = options.apiStatus;
  err.isOffline = options.isOffline;
  err.isRetryable = options.isRetryable ?? (options.status ? options.status >= 500 : true);
  return err;
}

async function requestWithRetry<T>(
  path: string,
  options: RequestInit = {},
  retryCount = 0
): Promise<ApiResponse<T>> {
  const maxRetries = 3;
  const url = `${BASE_URL}${path}`;

  const token = await getAuthToken();
  const authHeaders: Record<string, string> = {};
  if (token) {
    authHeaders['Authorization'] = `Bearer ${token}`;
  }

  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);

  try {
    const online = await isOnline();
    if (!online) {
      throw createApiError('Device is offline', { isOffline: true, isRetryable: true, code: 'OFFLINE' });
    }

    const response = await fetch(url, {
      headers: { ...DEFAULT_HEADERS, ...authHeaders, ...options.headers },
      ...options,
      signal: controller.signal,
    });

    clearTimeout(timeoutId);

    if (response.status === 401 && retryCount === 0) {
      const newToken = await refreshAuthToken();
      if (newToken) {
        return requestWithRetry(path, options, retryCount + 1);
      }
    }

    if (!response.ok) {
      let errorDetail = `HTTP ${response.status}`;
      let apiStatus = 'ERROR';
      try {
        const errorData = await response.json();
        errorDetail = errorData.detail || errorDetail;
        apiStatus = errorData.api_status || apiStatus;
      } catch {}

      const isRetryable = response.status >= 500 || response.status === 429;
      
      if (isRetryable && retryCount < maxRetries) {
        await new Promise(r => setTimeout(r, Math.min(1000 * 2 ** retryCount, 10000)));
        return requestWithRetry(path, options, retryCount + 1);
      }

      throw createApiError(errorDetail, { 
        status: response.status, 
        apiStatus, 
        isRetryable,
        code: response.status === 401 ? 'UNAUTHORIZED' : response.status === 403 ? 'FORBIDDEN' : 'REQUEST_FAILED'
      });
    }

    const data = await response.json();
    return { data, error: null, fromCache: false };
  } catch (err: any) {
    clearTimeout(timeoutId);
    
    if (err.name === 'AbortError' || err.code === 'ECONNABORTED') {
      if (retryCount < maxRetries) {
        await new Promise(r => setTimeout(r, Math.min(1000 * 2 ** retryCount, 10000)));
        return requestWithRetry(path, options, retryCount + 1);
      }
      throw createApiError('Request timeout', { isRetryable: true, code: 'TIMEOUT' });
    }

    if (err.isOffline) throw err;

    if (retryCount < maxRetries && err.isRetryable !== false) {
      await new Promise(r => setTimeout(r, Math.min(1000 * 2 ** retryCount, 10000)));
      return requestWithRetry(path, options, retryCount + 1);
    }

    throw err;
  }
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const result = await requestWithRetry<T>(path, options);
  if (result.error) throw result.error;
  return result.data!;
}

// ─── Health ──────────────────────────────────────────────
export const healthCheck = () => request<any>('/api/v5/health');

// ─── Metadata ────────────────────────────────────────────
export const getFaq = () => request<any>('/api/v5/faq');
export const getCropsMetadata = () => request<any>('/api/v5/crops/metadata');

// ─── Dashboard ───────────────────────────────────────────
export const getDashboard = () => request<any>('/api/v5/dashboard');

// ─── Batches ─────────────────────────────────────────────
export const createBatch = (data: {
  initial_weight_kg: number;
  crop_type?: string;
  variety?: string;
  latitude?: number | null;
  longitude?: number | null;
  field_name?: string;
  field_id?: string;
  detected_ripeness_stage?: string;
  visual_quality_score?: number;
  harvest_timestamp?: string;
  qr_code_secure_token?: string;
}) =>
  request<any>('/api/v5/batches/harvest', {
    method: 'POST',
    body: JSON.stringify(data),
  });

export const listBatches = (status?: string, limit = 50) => {
  const params = new URLSearchParams({ limit: String(limit) });
  if (status) params.set('status', status);
  return request<any>(`/api/v5/batches?${params}`);
};

export const getBatch = (batchId: string) =>
  request<any>(`/api/v5/batches/${batchId}`);

export const updateBatchStatus = (batchId: string, newStatus: string) =>
  request<any>(`/api/v5/batches/${batchId}/status?new_status=${newStatus}`, {
    method: 'PATCH',
  });

export const deleteBatch = (batchId: string) =>
  request<any>(`/api/v5/batches/${batchId}`, {
    method: 'DELETE',
  });

// ─── Notifications & Scans ───────────────────────────────
export const getNotifications = () => request<any>('/api/v5/notifications');
export const markNotificationAsRead = (notificationId?: string) =>
  request<any>(`/api/v5/notifications/read${notificationId ? `?id=${notificationId}` : ''}`, {
    method: 'POST',
  });
export const getRecentScans = () => request<any>('/api/v5/scans/recent');

// ─── Environmental Logs ──────────────────────────────────
export const ingestLog = (data: {
  batch_id: string;
  temperature_c: number;
  humidity_pct: number;
  latitude?: number;
  longitude?: number;
}) =>
  request<any>('/api/v5/logs', {
    method: 'POST',
    body: JSON.stringify(data),
  });

export const getLogs = (batchId: string, limit = 100) =>
  request<any>(`/api/v5/logs/${batchId}?limit=${limit}`);

// ─── Harvest Evaluation (4-layer pipeline) ───────────────
export interface HarvestEvaluationParams {
  batch_id: string;
  batch_weight_kg: number;
  is_vehicle_ventilated: boolean;
  co_habitants_json: string;
  destinations_json: string;
  latitude?: number;
  longitude?: number;
  samples?: Array<{
    base64: string;
    gps: { lat: number; lng: number } | null;
    sequence: number;
  }>;
}

export const evaluateHarvest = async (params: HarvestEvaluationParams) => {
  const formData = new FormData();

  const samples = params.samples ?? [];
  const hasSamples = samples.length > 0;
  
  if (hasSamples) {
    samples.forEach((sample, idx) => {
      const binaryStr = atob(sample.base64);
      const bytes = new Uint8Array(binaryStr.length);
      for (let i = 0; i < binaryStr.length; i++) bytes[i] = binaryStr.charCodeAt(i);
      const blob = new Blob([bytes], { type: 'image/webp' });
      formData.append(`sample_${idx}`, blob, `sample_${sample.sequence}.webp`);
    });
  } else {
    const pngData = 'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mNk+M9QDwADhgGAWjR9awAAAABJRU5ErkJggg==';
    const binaryStr = atob(pngData);
    const bytes = new Uint8Array(binaryStr.length);
    for (let i = 0; i < binaryStr.length; i++) bytes[i] = binaryStr.charCodeAt(i);
    const blob = new Blob([bytes], { type: 'image/png' });
    formData.append('file', blob, 'placeholder.png');
  }

  const queryParams = new URLSearchParams({
    batch_id: params.batch_id,
    batch_weight_kg: String(params.batch_weight_kg),
    is_vehicle_ventilated: String(params.is_vehicle_ventilated),
    co_habitants_json: params.co_habitants_json,
    destinations_json: params.destinations_json,
  });
  if (params.latitude) queryParams.set('latitude', String(params.latitude));
  if (params.longitude) queryParams.set('longitude', String(params.longitude));
  if (hasSamples) queryParams.set('sample_count', String(params.samples!.length));

  const token = await getAuthToken();
  const authHeaders: Record<string, string> = {};
  if (token) {
    authHeaders['Authorization'] = `Bearer ${token}`;
  }

  const response = await fetch(
    `${BASE_URL}/api/v5/harvest/evaluate-all?${queryParams}`,
    { method: 'POST', body: formData, headers: authHeaders }
  );

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'Harvest evaluation failed' }));
    throw createApiError(error.detail || `HTTP ${response.status}`, { 
      status: response.status,
      apiStatus: error.api_status,
    });
  }

  return response.json();
};

// ─── Salvage Facilities ──────────────────────────────────
export const getNearbySalvage = (
  latitude: number,
  longitude: number,
  radiusKm = 50
) =>
  request<any>(
    `/api/v5/salvage/nearby?latitude=${latitude}&longitude=${longitude}&radius_km=${radiusKm}`
  );

// ─── Passport ────────────────────────────────────────────
export const getPassport = (batchId: string) =>
  request<any>(`/api/v5/passport/${batchId}`);

export const generatePassport = (data: {
  batch_id: string;
  crop_type: string;
  weight_kg: number;
  visual_score: number;
  expiry_days?: number;
}) =>
  request<any>('/api/v5/passport/generate', {
    method: 'POST',
    body: JSON.stringify(data),
  });

export const verifyPassport = (token: string) =>
  request<any>(`/api/v5/passport/verify?token=${encodeURIComponent(token)}`, { method: 'POST' });

// ─── Satellite / VEDAS ──────────────────────────────────
export interface SatelliteData {
  source: string;
  latitude: number | null;
  longitude: number | null;
  ndvi_value: number | null;
  ndvi_modifier: number;
  modifier_applied: boolean;
  api_status: string;
  grid_features_found: number;
  soil_moisture?: number | null;
}

export const getVedasLive = (latitude: number, longitude: number) =>
  request<SatelliteData>(
    `/api/v5/satellite/vedas/live?latitude=${latitude}&longitude=${longitude}`
  );

// ─── Weather (Backend Proxy) ───────────────────────────
export interface WeatherData {
  source: string;
  temp: number;
  humidity: number;
  description: string;
  icon: string;
  feels_like: number;
  wind_speed: number;
  location_name: string;
  rain_chance: number;
  api_status: string;
  rain?: { '1h'?: number; '3h'?: number };
}

export const getWeatherByCoords = (
  latitude: number,
  longitude: number
) => request<WeatherData>(
  `/api/v5/weather?latitude=${latitude}&longitude=${longitude}`
);

// ─── Weather Alerts (Spoilage Risk) ────────────────────
export interface WeatherAlert {
  severity: string;
  icon: string;
  title: string;
  description: string;
  recommended_action: string;
  spoilage_risk_pct: number;
}

export interface WeatherAlertsResponse {
  crop_type: string;
  weather_summary: { temp_c: number; humidity_pct: number; description: string; rain_chance_pct: number };
  thermal_acceleration_factor: number;
  alerts: WeatherAlert[];
  timestamp: string;
  api_status?: string;
}

export interface AggregatedVisionResult {
  crop_identified: string;
  visual_quality_score: number;
  ripeness_stage: 'Unripe' | 'Optimal' | 'Overripe';
  fungal_pathogen_presence: boolean;
  confidence: number;
  sampleCount: number;
  individualResults: unknown[];
}

export const getWeatherAlerts = (
  latitude: number,
  longitude: number,
  cropType: string = 'Tomato'
) => request<WeatherAlertsResponse>(
  `/api/v5/weather/alerts?latitude=${latitude}&longitude=${longitude}&crop_type=${cropType}`
);

// ─── What-If Simulation ─────────────────────────────────
export interface WhatIfScenario {
  id: string;
  title: string;
  subtitle: string;
  icon: string;
  estimated_price_per_kg: number;
  expected_net_profit_inr: number;
  shelf_life_remaining_days: number;
  risk_level: string;
  risk_score: number;
  decay_velocity: number;
  reasoning: string[];
  is_recommended?: boolean;
  transit_hours?: number;
  freight_cost_inr?: number;
  storage_cost_inr?: number;
  backup_plan_b_route?: any;
}

export interface WhatIfResponse {
  crop_type: string;
  quantity_kg: number;
  visual_score: number;
  ambient_temp_c: number;
  decay_velocity: number;
  base_shelf_life_days: number;
  weather: any;
  scenarios: WhatIfScenario[];
  timestamp: string;
}

export const simulateWhatIf = async (data: {
  crop_type: string;
  quantity_kg: number;
  visual_score?: number;
  ambient_temp_c?: number;
  latitude?: number;
  longitude?: number;
  ethylene_multiplier?: number;
}): Promise<WhatIfResponse> => {
  const token = await getAuthToken();
  const headers: Record<string, string> = { 'Content-Type': 'application/json' };
  if (token) headers['Authorization'] = `Bearer ${token}`;

  const response = await fetch(`${BASE_URL}/api/v5/whatif/simulate`, {
    method: 'POST',
    headers,
    body: JSON.stringify(data),
  });
  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'Request failed' }));
    throw createApiError(error.detail || `HTTP ${response.status}`, { 
      status: response.status,
      apiStatus: error.api_status,
    });
  }
  return response.json();
};

// ─── Mandi Prices ─────────────────────────────────────
export interface MandiPrice {
  market: string;
  state: string;
  modal_price: number;
  min_price: number;
  max_price: number;
  commodity: string;
  arrival_date: string;
  distance_km?: number;
}

export interface MandiPricesResponse {
  source: string;
  crop: string;
  prices: MandiPrice[];
  count: number;
  trend?: string;
  api_status: string;
}

export const getMandiPrices = (crop: string, state?: string): Promise<MandiPricesResponse> => {
  const params = new URLSearchParams({ crop });
  if (state) params.set('state', state);
  return request<MandiPricesResponse>(`/api/v5/mandi/prices?${params}`);
};

// ─── Log Analytics ──────────────────────────────────────
export interface LogAnalytics {
  log_count: number;
  temperature: { min_c: number | null; avg_c: number | null; max_c: number | null };
  humidity: { min_pct: number | null; avg_pct: number | null; max_pct: number | null };
  temperature_trend: string;
  degree_hours_above_optimal: number;
  spoilage_risk_class: string;
  spoilage_risk_pct: number;
  first_log_timestamp: string | null;
  last_log_timestamp: string | null;
}

export const getLogAnalytics = (batchId: string) =>
  request<{ batch_id: string; analytics: LogAnalytics }>(`/api/v5/logs/${batchId}/analytics`);

// ─── Offline Sync ────────────────────────────────────────
export const syncOfflineQueue = (data: {
  farmer_id: string;
  device_sync_timestamp: string;
  transactions: any[];
}) =>
  request<any>('/api/v5/sync/process-queue', {
    method: 'POST',
    body: JSON.stringify(data),
  });

// ─── Vision Analysis (single image) ────────────────────
export interface VisionResult {
  crop_identified: string;
  visual_quality_score: number;
  ripeness_stage: 'Unripe' | 'Optimal' | 'Overripe';
  fungal_pathogen_presence: boolean;
  confidence: number;
}

export const analyzeImage = async (imageBase64: string, mimeType = 'image/webp'): Promise<VisionResult> => {
  const formData = new FormData();
  const binaryStr = atob(imageBase64);
  const bytes = new Uint8Array(binaryStr.length);
  for (let i = 0; i < binaryStr.length; i++) bytes[i] = binaryStr.charCodeAt(i);
  const blob = new Blob([bytes], { type: mimeType });
  formData.append('file', blob, 'crop.webp');

  const token = await getAuthToken();
  const authHeaders: Record<string, string> = {};
  if (token) authHeaders['Authorization'] = `Bearer ${token}`;

  const response = await fetch(`${BASE_URL}/api/v5/vision/analyze`, {
    method: 'POST',
    body: formData,
    headers: authHeaders,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'Vision analysis failed' }));
    throw createApiError(error.detail || `HTTP ${response.status}`, { 
      status: response.status,
    });
  }

  return response.json();
};

export const analyzeBatch = async (imagesBase64: string[], mimeType = 'image/webp', cropType: string, latitude: number, longitude: number) => {
  const formData = new FormData();
  
  imagesBase64.forEach((base64, index) => {
    const binaryStr = atob(base64);
    const bytes = new Uint8Array(binaryStr.length);
    for (let i = 0; i < binaryStr.length; i++) bytes[i] = binaryStr.charCodeAt(i);
    const blob = new Blob([bytes], { type: mimeType });
    formData.append('files', blob, `crop_${index}.webp`);
  });

  formData.append('crop_type', cropType);
  formData.append('latitude', latitude.toString());
  formData.append('longitude', longitude.toString());

  const token = await getAuthToken();
  const authHeaders: Record<string, string> = {};
  if (token) authHeaders['Authorization'] = `Bearer ${token}`;

  const response = await fetch(`${BASE_URL}/api/v5/vision/analyze-batch`, {
    method: 'POST',
    body: formData,
    headers: authHeaders,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ detail: 'Batch analysis failed' }));
    throw createApiError(error.detail || `HTTP ${response.status}`, { 
      status: response.status,
    });
  }

  return response.json();
};
