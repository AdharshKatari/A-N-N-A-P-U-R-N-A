import psycopg2

conn = psycopg2.connect('postgres://avnadmin:AVNS_33570aoBUOJbC4VEPk9@pg-2bd28f24-shahidkhan07191-2f4c.k.aivencloud.com:28479/defaultdb?sslmode=require')
conn.autocommit = True
cur = conn.cursor()

with open(r'C:\Users\HP\OneDrive\Documents\webd\task\The Farmer Market\init_spatial_schema.sql', 'r', encoding='utf-8', errors='ignore') as f:
    sql = f.read()

# Split by semicolon and execute each statement
statements = sql.split(';')
for stmt in statements:
    stmt = stmt.strip()
    if stmt and not stmt.startswith('--'):
        try:
            cur.execute(stmt)
            print(f"OK: {stmt[:80]}...")
        except Exception as e:
            print(f"ERROR: {e}")

cur.close()
conn.close()
print("Done")