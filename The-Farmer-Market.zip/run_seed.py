import psycopg2

conn = psycopg2.connect('postgres://avnadmin:AVNS_33570aoBUOJbC4VEPk9@pg-2bd28f24-shahidkhan07191-2f4c.k.aivencloud.com:28479/defaultdb?sslmode=require')
conn.autocommit = True
cur = conn.cursor()

with open(r'C:\Users\HP\OneDrive\Documents\webd\task\The Farmer Market\backend\seed_data.sql', 'r', encoding='utf-8', errors='ignore') as f:
    sql = f.read()

try:
    cur.execute(sql)
    print("Seed data inserted successfully")
except Exception as e:
    print(f"ERROR: {e}")

cur.close()
conn.close()
print("Done")