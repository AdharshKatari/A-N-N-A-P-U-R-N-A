import requests
r = requests.get('http://localhost:8082')
print('Frontend status:', r.status_code)
print('Has React root:', 'id="root"' in r.text)
print('Has Annapurna title:', 'Annapurna' in r.text)